const images = {
  parent: require('./robot-dev.png'),
  bsitter: require('./Phuc.png'),
  child: require('./Baby-6.png'),
};

export default images;
