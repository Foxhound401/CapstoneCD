export const Gender = {
    MALE: 'Nam',
    FEMALE: 'Nữ',
}